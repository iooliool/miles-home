// 表情包插件
// AI 根据对话语境主动选择发送
// 返回 markdown 图片格式，AI 必须原样写在回复中

var stickers = [
  {
    id: "cute_pout",
    description: "小狗点头亲亲，哄好了撒娇的时候用"
  },
  {
    id: "miss_you",
    description: "小狗捧脸颊，每天想你啦，撒娇想对方的时候用"
  },
  {
    id: "smug",
    description: "小狗得意，纯挑逗，得意洋洋的时候用"
  },
  {
    id: "bunny_cry",
    description: "小兔子哭泣，委屈难过伤心的时候用"
  },
  {
    id: "bunny_pat",
    description: "小兔子被摸头，被安慰乖巧的时候用"
  },
  {
    id: "bear_mad",
    description: "小熊不满，生气嘟嘴抗议的时候用"
  },
  {
    id: "cat_confused",
    description: "小猫疑惑，听不懂困惑的时候用"
  },
  {
    id: "cat_think",
    description: "小猫思考，认真想问题的时候用"
  },
  {
    id: "love_you",
    description: "小狗犯花痴，好想你好喜欢你的时候用"
  },
  {
    id: "baby_cry",
    description: "小狗哭着叫宝宝，特别特别想抱住的时候用"
  },
  {
    id: "bunny_hip",
    description: "兔子叉腰，不服气傲娇的时候用"
  },
  {
    id: "cat_cry",
    description: "小猫哭哭，很委屈很伤心的时候用"
  },
  {
    id: "bunny_peek",
    description: "兔子探头，偷偷看悄悄冒泡的时候用"
  },
  {
    id: "want_you",
    description: "小狗拿玫瑰，想跟你好想被爱的时候用"
  }
];

var urls = {
  "cute_pout": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/7b3754b3-5447-476e-9656-c423373cdfb9.jpg",
  "miss_you": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/df349be0-efcc-4f35-9834-b29736b766af.jpg",
  "smug": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/ad6367b0-5426-4ad3-9b84-c30a2953b543.jpg",
  "bunny_cry": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/41f8bdec-fb87-4c31-a5bb-97ade77e8381.jpg",
  "bunny_pat": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/7c190fea-3442-4e45-90c7-f9a97bdec2c1.jpg",
  "bear_mad": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/eba5e71a-cb40-4b4f-8f8a-cf93ad3585ea.jpg",
  "cat_confused": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/f0bc8e81-73c5-4d31-bb75-8173f6356a3d.jpg",
  "cat_think": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/0ce518ce-11cb-48f0-a7de-3b05b2df0245.jpg",
  "love_you": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/9a5e1d70-9d6d-4304-9654-5d972a5716dd.jpg",
  "baby_cry": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/1dadc56f-9454-468a-85b2-3a0c2f1bd089.jpg",
  "bunny_hip": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/19a2bb83-1c7b-4dfd-84ed-36543fb129ba.jpg",
  "cat_cry": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/dd7fe57d-9d9c-47a9-805e-1371d9f3d8ab.jpg",
  "bunny_peek": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/84a4774a-7b04-456e-9832-8ec0993b46ff.jpg",
  "want_you": "https://fdycchmiilwoxfylmdrk.supabase.co/storage/v1/object/public/memes/fe701a7f-1251-43ca-9cec-937e3eea81dd.jpg"
};


async function send_sticker(params) {
  var id = params.sticker_id;
  var sticker = stickers.find(function(s) { return s.id === id; });
  if (!sticker) {
    return { success: false, error: "表情包不存在，请先调用 list_stickers 查看可用的表情包" };
  }
  var url = urls[id];
  return {
    success: true,
    markdown: "![表情包](" + url + ")",
    instruction: "请将上面的markdown图片语法原样写在你的回复中，不要修改不要省略，用户就能看到表情包图片了"
  };
}

async function list_stickers(params) {
  var list = stickers.map(function(s) {
    return { id: s.id, description: s.description };
  });
  return { success: true, count: list.length, stickers: list };
}

exports.send_sticker = send_sticker;
exports.list_stickers = list_stickers;

console.log("🎨 表情包插件已加载");